import './App.css';
// import {Home} from './components/home'; named export
import MyHome from './components/home';
import Info from './components/info';
import About from './components/about';

function App() {
  return (
    <div>
        {/* <MyHome /> */}
        {/* <Info name="santhosh"/> */}
        {/* <About name="santhosh" age="18"> <h2> Just for demo child property </h2> </About>
        <About name="rakesh" age="19"/>
        <About name="eric" age="20"/>
        <About name="rahul" age="21"/> */}

        {/* <Info></Info> */}

        <About name="Sanju" age="22"></About>

    </div>
  );
}
export default App;
