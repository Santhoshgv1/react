import { Component } from 'react';
import './info.css';

class Info extends Component {

    constructor() {
        super()
        this.state = {
            greet: " welcome santhosh",
            name:"raj"
        }
    }
    changeGreet() {
        this.setState({
            greet:"welcome ganesh",
            name:"raj kumar"
        });
    }
    render() {
        return (
            <div>
                {/* <h1> this is class Component {this.props.name}</h1> */}
                <h1> {this.state.greet} </h1>
                <button onClick={() => { this.changeGreet() }}> greet </button>
            </div>
        );
    }
}
export default Info;