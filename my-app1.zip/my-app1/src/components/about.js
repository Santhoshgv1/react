import React, { useState } from 'react';

const About = (props) => {
  //1  return  React.createElement('div',null,React.createElement('h1',{id:'demo', class:'demo1'},'hello everyone'))

  const [car,setCar] = useState({ name:"hundai" ,model :"2021", condition:"good" });

  const updateDetails=()=>
  {
    // setCar( (pre)=>{
    //   return { ...pre, name:"BMW"}
    // } );

    setCar( ()=>{
     return { name:"verna", model:2022, condition:"v good"}
    } );

  }
  return (
    <div>
      <h1>props</h1>
      <h1>hello everyone {props.name} , {props.age} {props.children} </h1>
      <hr />
      <div>
        <h1>state</h1> 
        <h3>Car name is {car.name} and model is {car.model} with {car.condition} condition </h3>
      {/* <button onClick={()=>{ setCar( {name:'verna',model:'2010',condition :'bad'})  }}>change </button> */}
      <button onClick={updateDetails}>change </button>
      </div>

      
    </div>
  )
}
export default About;


