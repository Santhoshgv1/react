import React from 'react';
import './home.css';

// function Home()
// {
//     return( <div>
//         <h1> This is Home component</h1>
//     </div> );
// }

//  -------------named export ------------------
// export const Home = ()=>{                                       
//     return( <div>
//          <h1> this is home component</h1>
//      </div>);
//  };

function Home() {
    return (<div>
        <h1 > this is functional component </h1>
        <p>demo text </p>
    </div>);
}

export default Home;  // ----defalt export-----